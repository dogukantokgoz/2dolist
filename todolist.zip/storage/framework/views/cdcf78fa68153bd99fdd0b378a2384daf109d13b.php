<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-md-6 mx-auto my-5">
<form method="POST" action="<?php echo e(route('store')); ?>">
    <?php echo csrf_field(); ?>
<div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" class="form-control" name="title" placeholder="Add title">
</div>
<div class="mb-3">
    <label class="form-label">Description</label>
    <textarea class="form-control" name="description" placeholder="Add desscription" rows="3"></textarea>
</div>
    <div align="right">
    <button type="submit" class="btn btn-primary">Oluştur</button>
    </div>

</div>
</form>
<?php /**PATH C:\laragon\www\todolist\resources\views/create.blade.php ENDPATH**/ ?>