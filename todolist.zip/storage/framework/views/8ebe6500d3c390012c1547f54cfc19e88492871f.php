<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<head>
    <title>2dolist | Silinenler</title>
</head>
<body>
<div class="col-md-6 mx-auto">
    <p><h2>SİLİNENLER</h2>

            <?php if(count($todos) > 0): ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th>Başlık</th>
                        <th>
                            <div class="d-flex justify-content-end">Seçenekler</div></th>
                    </tr>
                    </thead>
                    <tbody>
            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-light">
                    <td><?php echo e($todo->title); ?></td>
                    <td>
                        <div class="d-flex justify-content-end">

                            <a href="<?php echo e(route('recover', $todo->id)); ?>"><button type="submit" name="recover" class="btn btn-primary">Geri Yükle</button></a>
                            <a href="<?php echo e(route('delete', $todo->id)); ?>"><button type="submit" name="recover" class="btn btn-danger">Sil</button></a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <table class="table">
            <thead>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th>
                    <div class="d-flex justify-content-end"></div></th>
            </tr>
            </thead>
            <tbody>
        <tr class="table-light">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td><p><h5>Silinenler listeniz boş</h5></td>
            <td>
            </td>
        </tr>
        </tbody>
        </table>
    <?php endif; ?>
</div>
</div>
</body>


<?php /**PATH C:\laragon\www\todolist\resources\views/trashed.blade.php ENDPATH**/ ?>