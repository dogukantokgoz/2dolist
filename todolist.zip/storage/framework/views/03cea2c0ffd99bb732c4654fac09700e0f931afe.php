<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<head>
    <title>2dolist | Anasayfa</title>
</head>
<body>

<div class="col-md-8 mx-auto">
    <p><h2>Yapılacaklar Listesi</h2>
    <div class="d-flex justify-content-end">
        <a href="<?php echo e(route('create')); ?>"><button type="button" name="create" class="btn btn-dark">Oluştur</button></a>
    </div>
    </p>

    <?php if(count($todos) > 0): ?>


    <table class="table">
        <thead>
        <tr>
            <th>Başlık</th>
            <th>Oluşturulma Tarihi</th>
            <th>Durum</th>
            <th>Seçenekler</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php if($todo->status == 0): ?>table-primary <?php else: ?> table-success <?php endif; ?>">
            <td><?php echo e($todo->title); ?></td>
            <td><?php echo e($todo->created_at->diffForHumans()); ?></td>
            <td><?php if($todo->status == 0): ?> Devam Ediyor <?php else: ?> Tamamlandı <?php endif; ?></td>
            <td>
                <a href="<?php echo e(route('edit', $todo->id)); ?>"><button type="button" class="btn btn-primary">Düzenle</button></a>
                <a href="<?php echo e(route('show', $todo->id)); ?>"><button type="button" class="btn btn-secondary">Göster</button></a>
                <form style="display:inline-block" method="post" action="<?php echo e(route('destroy')); ?>" class="inner">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button value="<?php echo e($todo->id); ?>" type="submit" name="todo_id" class="btn btn-danger">Sil</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <table class="table">
            <thead>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th>
                    <div class="d-flex justify-content-end"></div></th>
            </tr>
            </thead>
            <tbody>
            <tr class="table-light">
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><p><h5>Yapılacaklar listeniz boş</h5>
                </td>
            </tr>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</div>
</body>


<?php /**PATH C:\laragon\www\todolist\resources\views/index.blade.php ENDPATH**/ ?>