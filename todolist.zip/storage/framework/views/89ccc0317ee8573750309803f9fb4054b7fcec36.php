<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-md-8 mx-auto">
    <form method="POST" action="<?php echo e(route('update')); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="todo_id" value="<?php echo e($todo->id); ?>">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" value="<?php echo e($todo->title); ?>" class="form-control" name="title" placeholder="Add title">
        </div>
        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" name="description" placeholder="Add desscription" rows="3"><?php echo e($todo->description); ?></textarea>
        </div>
        <div class="mb-3">
            <select class="form-select" name="status">
                <option value="0" <?php if($todo->status == 0): ?> selected <?php endif; ?>>Devam Ediyor</option>
                <option value="1" <?php if($todo->status == 1): ?> selected <?php endif; ?>>Tamamlandı</option>
            </select>
        </div>
<div align="right">
        <button type="submit" class="btn btn-primary">Güncelle</button>
    </form>
    <form style="display:inline-block" method="post" action="<?php echo e(route('destroy')); ?>" class="inner">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button value="<?php echo e($todo->id); ?>" type="submit" name="todo_id" class="btn btn-danger">Sil</button>
    </form>
</div>
</div>

<?php /**PATH C:\laragon\www\todolist\resources\views/edit.blade.php ENDPATH**/ ?>