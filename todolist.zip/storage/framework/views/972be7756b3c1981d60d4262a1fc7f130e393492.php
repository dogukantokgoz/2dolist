<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<div class="col-md-8 mx-auto">
<ol class="list-group list-group">
    <li class="list-group-item d-flex justify-content-between align-items-start">
        <div class="ms-2 me-auto">
            <div class="fw-bold">Title</div>
            <?php echo e($todo->title); ?>

        </div>
    </li>
</ol>
    <br>
    <ol class="list-group list-group">
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Description</div>
                <?php echo e($todo->description); ?>

            </div>
        </li>
    </ol>
    <br>
    <ol class="list-group list-group">
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Status</div>
                <?php if($todo->status == 1): ?>
                    <span class="text-success">Tamamlandı</span>
                <?php else: ?>
                    <span class="text-primary">Devam Ediyor</span>
                <?php endif; ?>
            </div>
                <?php if($todo->status == 0): ?> <span class="badge bg-primary "> <?php echo e($todo->created_at->diffForHumans()); ?>

                <?php else: ?> <span class="badge bg-success "> ✓ <?php endif; ?></span>
        </li>
    </ol>
</div>
<?php /**PATH C:\laragon\www\todolist\resources\views/show.blade.php ENDPATH**/ ?>